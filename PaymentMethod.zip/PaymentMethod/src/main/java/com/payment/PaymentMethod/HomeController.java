package com.payment.PaymentMethod;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class HomeController {
    @RequestMapping(value="/payments",method= RequestMethod.GET)
    public String paymentsPage()
    {
        return "payments";
    }
    @RequestMapping(value="/payments",method= RequestMethod.POST)
    public String xmlPage()
    {
        return "Aftersubmit";
    }

}
